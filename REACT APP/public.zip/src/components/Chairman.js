import React from 'react';
import './Chairman.css';

const Chairman = () => {
  return (
    <div className="chairman-section">
      <div className="chairman-header">
        <h1>From the Desk of Chairman</h1>
        <p>Your Vision, Our Inspiration</p>
      </div>

      <div className="chairman-content">
        <img src="/chairman.png" alt="Chairman" className="chairman-image" /> 
        
        <div className="message-section">
          <h2>President – Shri Raju Anant Patil</h2>
          <p>
            It gives us great pleasure in extending a warm welcome to all our student fraternity, parents, and our entire management.
          </p>
          <p>
            We believe that teamwork is better than individual work. Our institution team, blended with pre-primary, primary, secondary, 
            higher secondary, and degree college, has grown into a dynamic educational community.
          </p>
          
          <h3>Our Institutions:</h3>
          <ul>
            <li>Parsharam Dhondu Tawre Vidyalaya, Kalher</li>
            <li>Premabai Sukrysa Patil Vidyalaya, Kariwli, Bhiwandi</li>
            <li>Sitaram Rama Patil Vidyalaya, Amne, Bhiwandi</li>
            <li>Madhavra Patil Balmandir, Kalher, Bhiwandi</li>
            <li>Abhinav Bal Vidyamandir English Medium School, Tadali, Bhiwandi</li>
            <li>Anant Laxman Patil (Master) Junior College, Kalher, Bhiwandi</li>
            <li>Smt. Pushpalata Madhukar Madhavi College of Commerce, Science & Arts, Kalher, Bhiwandi</li>
            <li>Smt. Chandrabai Anant Patil English Medium High School & Junior College, Kalher</li>
          </ul>

          <p>
            As per our vision, we celebrate various events such as Azadi Ka Amrut Mohotsav, Navratri Utsav, Khel Mohotsav, industrial visits, 
            traditional day celebrations, NSS activities, seminar sessions, as well as inter-college fests like Push Parang and Anant Tarang Mohotsav.
          </p>

          <h4>Shri Raju Anant Patil</h4>
        </div>
      </div>
    </div>
  );
};

export default Chairman;
