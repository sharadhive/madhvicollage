import React from 'react';
import './Faculties.css';

const facultyData = [
  { srNo: 1, male: "Mr. Tushar Mohan Madhavi", srNoFemale: 1, female: "Ms. Divya Chandrakant Bhoir" },
  { srNo: 2, male: "Mr. Tushar Mohan Madhavi", srNoFemale: 2, female: "Mrs. Ujwala Bharat Jadhav" },
  { srNo: 3, male: "Mr. Kunal Baliram Bhokre", srNoFemale: 3, female: "Mrs. Pratibha Pradip Bhosle" },
  { srNo: 4, male: "Mr. Jaynath Dunda Patil", srNoFemale: 4, female: "Mrs. Vaishali Jaidip Patil" }
];

const Faculties = () => {
  return (
    <div className="faculties-section">
      <div className="faculties-header">
        <h1>Our Esteemed Teaching Faculty</h1>
        <p>Meet our dedicated faculty members who shape the future of our students.</p>
      </div>

      <div className="faculties-content">
        <h2>Teaching Faculty</h2>
        
        <div className="table-responsive">
          <table className="faculties-table">
            <thead>
              <tr>
                <th>Sr. No.</th>
                <th>Male Faculty</th>
                <th>Sr. No.</th>
                <th>Female Faculty</th>
              </tr>
            </thead>
            <tbody>
              {facultyData.map((faculty, index) => (
                <tr key={index}>
                  <td>{faculty.srNo}</td>
                  <td>{faculty.male}</td>
                  <td>{faculty.srNoFemale}</td>
                  <td>{faculty.female}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Faculties;
