import React from 'react';
import './Testimonials.css';

const Testimonials = () => {
  return (
    <div className="testimonials-section">
      <div className="testimonials-container">
        <h2 className="testimonials-title">
          What Students Say About <span>Smt. Pushpalata Madhukar Madhavi College of Commerce</span>
        </h2>
        <div className="testimonials-content">
          <div className="testimonial-card">
            <p className="testimonial-quote">
              "This college has provided me with the best education and support. The faculty members are knowledgeable and always ready to help."
            </p>
            <p className="testimonial-author">- Rahul Sharma</p>
            <div className="testimonials-rating">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star-half-alt"></i>
            </div>
          </div>
          <button className="explore-more-btn">Read More</button>
        </div>
      </div>
    </div>
  );
};

export default Testimonials;
