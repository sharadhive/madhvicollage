import React from 'react';
import { Carousel } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Facilities.css';  // Custom CSS for additional styling

const facilitiesData = [
  {
    title: "Class Rooms",
    description: "Class rooms are spacious, well ventilated and fully equipped with audio visual devices.",
    imgSrc: "/lab.jpg",
    link: "#"
  },
  {
    title: "Sports Infra",
    description: "We offer facilities for indoor and outdoor sports, promoting overall student fitness.",
    imgSrc: "/lab.jpg",
    link: "#"
  },
  {
    title: "Computer Labs",
    description: "We have a well-equipped Computer Laboratory with broadband internet connection.",
    imgSrc: "/lab.jpg",
    link: "#"
  },
  {
    title: "Campus Interviews",
    description: "We organize Campus Placement drives to help our students with corporate exposure.",
    imgSrc: "/lab.jpg",
    link: "#"
  },
  {
    title: "Industrial Visits",
    description: "Students are taken to leading companies for industrial visits, enhancing practical exposure.",
    imgSrc: "/lab.jpg",
    link: "#"
  },
  {
    title: "NSS Activities",
    description: "We conduct National Service Scheme (NSS) activities including blood donation camps.",
    imgSrc: "/lab.jpg",
    link: "#"
  }
];

const Facilities = () => {
  // Grouping 3 items per carousel slide
  const groupedFacilities = [];
  for (let i = 0; i < facilitiesData.length; i += 3) {
    groupedFacilities.push(facilitiesData.slice(i, i + 3));
  }

  return (
    <div className="facilities-custom-section">
      <div className="container">
        <h2 className="facilities-custom-title text-center mb-4">Infrastructure and Facilities</h2>

        <Carousel indicators={false} interval={3000} controls={true} pause={false} wrap={true}>
          {groupedFacilities.map((group, index) => (
            <Carousel.Item key={index}>
              <div className="d-flex justify-content-center">
                {group.map((facility, idx) => (
                  <div className="card facility-card mx-2" key={idx}>
                    <img src={facility.imgSrc} alt={facility.title} className="card-img-top facility-img" />
                    <div className="card-body text-center">
                      <h5 className="card-title">{facility.title}</h5>
                      <p className="card-text">{facility.description}</p>
                      <a href={facility.link} className="btn btn-primary">View Profile</a>
                    </div>
                  </div>
                ))}
              </div>
            </Carousel.Item>
          ))}
        </Carousel>
      </div>
    </div>
  );
};

export default Facilities;
