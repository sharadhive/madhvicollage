// collegeapp\src\components\Event.js

import React from 'react';
import Gallery from './Gallery';
import './Event.css';

const Event = () => {
  return (
    <div className="event-page">
      <div className="event-header">
        <h1>Upcoming Events</h1>
        <p>Join us for our upcoming events and activities. Check out our gallery below!</p>
      </div>

      <Gallery />
    </div>
  );
};

export default Event;