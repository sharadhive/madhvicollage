import React from 'react';
import './BCom.css';  // Import the custom CSS for styling

const BCom = () => {
  return (
    <div className="bcom-page">
      <h1 className="page-title">Bachelor of Commerce</h1>

      <div className="bcom-syllabus">
        <h2 className="section-title">First Year Bachelor Programs</h2>
        <h3>F.Y.B.A</h3>
        <ul>
          <li>History (Ancient India)</li>
          <li>Economics (Microeconomics-I)</li>
          <li>Geography</li>
          <li>Basics of Agriculture-I</li>
          <li>Introduction to Indian Archeology</li>
          <li>Indian Constitution</li>
          <li>Communication Skills in English</li>
          <li>Indian Knowledge System</li>
        </ul>

        <h3>F.Y.B.Com</h3>
        <ul>
          <li>Accountancy and Financial Management-I</li>
          <li>Vocational Skills in Accounting-I</li>
          <li>Commerce-I</li>
          <li>Fundamental of Startups</li>
          <li>Microeconomics-I</li>
          <li>History of Buddhism</li>
          <li>Indian Constitution</li>
          <li>Business Communication</li>
          <li>Indian Knowledge System</li>
          <li>Introduction to Cultural Activities</li>
          <li>स्पर्धा परीक्षा पूर्वतयारी-निबंध लेखन व सारांशलेखन-l</li>
        </ul>

        <h3>F.Y.B.Sc</h3>
        <ul>
          <li>Chemistry (Basics in Physics, Inorganic and Organic Chemistry-I)</li>
          <li>Physics (Introduction to Mechanics)</li>
          <li>Mathematics (Algebra-I and Calculus-I)</li>
          <li>Calibration of Glassware and Instruments-I</li>
          <li>Basic Statistical Tools in Chemistry-I</li>
          <li>Indian Constitution</li>
          <li>Communication Skills in English</li>
          <li>Indian Knowledge System</li>
        </ul>

        <h2 className="section-title">Second Year Bachelor Programs</h2>
        <h3>S.Y.B.A</h3>
        <ul>
          <li>Foundation Course-II</li>
          <li>Business Communication</li>
          <li>History Paper II-Landmarks in World History 1300A.D-1945A.D</li>
          <li>History Paper III-Ancient India from Earliest Times to 1000 A.D</li>
          <li>Geography of Maharashtra</li>
          <li>Agricultural Geography</li>
          <li>Macroeconomics-I</li>
          <li>Public Finance</li>
        </ul>

        <h3>S.Y.B.Com</h3>
        <ul>
          <li>Foundation Course-Contemporary Issues-III</li>
          <li>Accountancy and Financial Management-III</li>
          <li>Financial Accounting and Auditing-Introduction to Management Accounting</li>
          <li>Commerce-III</li>
          <li>Business Economics-III</li>
          <li>Business Law-I</li>
          <li>Advertising-I</li>
        </ul>

        <h3>S.Y.B.Sc</h3>
        <ul>
          <li>Foundation Course-Contemporary Issues-III</li>
          <li>Chemistry Paper-I</li>
          <li>Chemistry Paper-II</li>
          <li>Chemistry Paper-III</li>
          <li>Physics Paper-I</li>
          <li>Physics Paper-II</li>
          <li>Physics Paper-III</li>
        </ul>

        <h2 className="section-title">Third Year Bachelor Programs</h2>
        <h3>T.Y.B.A</h3>
        <ul>
          <li>Advanced Microeconomics-III</li>
          <li>Economics of Growth and Development</li>
          <li>Economics of Agriculture and Co-Operation-I</li>
          <li>History: History of Medieval India (1000CE-1526CE)</li>
          <li>History: History of Modern Maharashtra (1818CE-1960CE)</li>
          <li>History: Introduction to Archaeology</li>
        </ul>

        <h3>T.Y.B.Com</h3>
        <ul>
          <li>Financial Accounting and Auditing VII-Financial Accounting</li>
          <li>Financial Accounting and Auditing VIII-Cost Accounting</li>
          <li>Business Economics-V</li>
          <li>Commerce-V</li>
          <li>Direct and Indirect Taxation Paper-I</li>
          <li>Export Marketing Paper-I</li>
        </ul>

        <h3>T.Y.B.Sc</h3>
        <ul>
          <li>Chemistry: Analytical Chemistry</li>
          <li>Chemistry: Inorganic Chemistry</li>
          <li>Chemistry: Organic Chemistry</li>
          <li>Chemistry: Physical Chemistry</li>
          <li>Drugs and Dyes</li>
        </ul>
      </div>
    </div>
  );
};

export default BCom;
