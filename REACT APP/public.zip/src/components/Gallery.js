// collegeapp\src\components\Gallery.js

import React, { useState } from 'react';
import { Modal } from 'react-bootstrap';
import './Gallery.css';

const galleryImages = [
  "/G1.jpg",
  "/G2.jpg",
  "/G3.jpg",
  "/G4.jpg",
  "/G5.jpg",
  "/G6.jpg",
];

const moreGalleryImages = [
  "/G7.jpg",
  "/G8.jpg",
  "/G9.jpg",
  "/G10.jpg",
  "/G11.jpg",
  "/G12.jpg",
];

const Gallery = () => {
  const [showModal, setShowModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState('');
  const [showMoreImages, setShowMoreImages] = useState(false);

  const handleImageClick = (image) => {
    setSelectedImage(image);
    setShowModal(true);
  };

  const handleMorePhotosClick = () => {
    setShowMoreImages(!showMoreImages);
  };

  return (
    <div className="gallery-section">
      <div className="gallery-container">
        <h2 className="gallery-title">Our Gallery</h2>
        <div className="gallery-grid">
          {galleryImages.map((image, index) => (
            <div className="gallery-item" key={index}>
              <img
                src={image}
                alt={`Gallery Image ${index + 1}`}
                className="gallery-img"
                onClick={() => handleImageClick(image)}
              />
            </div>
          ))}

          {showMoreImages && moreGalleryImages.map((image, index) => (
            <div className="gallery-item" key={index}>
              <img
                src={image}
                alt={`More Gallery Image ${index + 7}`}
                className="gallery-img"
                onClick={() => handleImageClick(image)}
              />
            </div>
          ))}
        </div>

        <button className="explore-more-btn" onClick={handleMorePhotosClick}>
          {showMoreImages ? "Show Less" : "Explore More Photos"}
        </button>

        <Modal show={showModal} onHide={() => setShowModal(false)} centered>
          <Modal.Body>
            <img src={selectedImage} alt="Selected" className="img-fluid" />
          </Modal.Body>
        </Modal>
      </div>
    </div>
  );
};

export default Gallery;