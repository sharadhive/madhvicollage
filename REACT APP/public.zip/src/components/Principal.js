import React from 'react';
import './Principal.css';

const Principal = () => {
  return (
    <div className="principal-section">
      <div className="principal-header">
        <h1>Message from the Principal</h1>
      </div>

      <div className="principal-content">
        <img src="/principal.png" alt="Principal" className="principal-image" />
        <div className="message-section">
          <p>
            At <strong>Smt. Pushpalata Madhukar Madhavi College of Commerce, Science & Arts</strong>, we believe that education is the foundation for positive change. Our institution is committed to fostering academic excellence, holistic development, and strong ethical values in our students.
          </p>
          <p>
            We strive to create an environment that encourages students to explore, innovate, and grow into responsible global citizens. Our approach is centered on quality education, critical thinking, and nurturing leadership qualities among students.
          </p>
          <p>
            We value the role of parents in a student's academic journey and maintain close communication to ensure their overall progress. Together, we aim to shape a generation that is well-equipped to face the challenges of the future.
          </p>
          <h4>Dr. Vivekkumar V. Patil</h4>
          <p>Principal</p>
        </div>
      </div>
    </div>
  );
};

export default Principal;
